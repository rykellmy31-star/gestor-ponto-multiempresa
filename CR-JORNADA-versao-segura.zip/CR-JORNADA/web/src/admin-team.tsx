
import {useEffect,useState} from 'react';
import {Link} from 'react-router-dom';
import {
  Users,LogIn,UserRoundX,Coffee,CheckCircle2,
  AlertTriangle,Clock3,MessageSquareText,Plus,Search,
  ArrowUpRight,RefreshCw,Eye,Pencil,KeyRound,Copy,
  CalendarClock,UserRound,ShieldCheck,XCircle,Trash2
} from 'lucide-react';
import {
  api,brDate,clock,errorMessage,hm,localInput,weekdayNames
} from './api';
import {useData,useSession} from './layout';
import {
  Badge,Button,Empty,ErrorScreen,Field,Initials,
  InlineError,Modal,Notice,PageHeader,Select,Spinner,
  Stat,useSecurity,useToast
} from './ui';

export function AdminDashboard(){
  const {config}=useSession();
  const today=localInput(config.server_now,config.timezone).slice(0,10);

  const [date,setDate]=useState(today);
  const [month,setMonth]=useState(today.slice(0,7));
  const [search,setSearch]=useState('');
  const [status,setStatus]=useState('all');

  const state=useData(`/admin/dashboard?date=${date}&month=${month}`);
  const d=state.data;

  const rows=d?.rows.filter((r:any)=>
    (
      r.employee.full_name.toLowerCase().includes(search.toLowerCase())||
      r.employee.registration.toLowerCase().includes(search.toLowerCase())
    )&&
    (status==='all'||r.day.status===status)
  )||[];

  return <>
    <PageHeader
      eyebrow="PAINEL DA EMPRESA"
      title="Visão geral"
      description="Uma visão clara da jornada da sua equipe, todos os dias."
      actions={
        <Button
          variant="secondary"
          icon={RefreshCw}
          busy={state.loading}
          onClick={state.reload}
        >
          Atualizar
        </Button>
      }
    />

    <div className="filter-bar dashboard-filters">
      <Field label="Data de acompanhamento">
        <input
          aria-label="Data de acompanhamento"
          type="date"
          min="1900-01-01"
          max="2100-12-31"
          value={date}
          onChange={e=>{if(e.target.value)setDate(e.target.value);}}
        />
      </Field>

      <Field label="Mês dos indicadores de horas">
        <input
          type="month"
          min="1900-01"
          max="2100-12"
          value={month}
          onChange={e=>{if(e.target.value)setMonth(e.target.value);}}
        />
      </Field>

      <div className="filter-hint">
        <span className="live-dot"/>
        Dados consultados no banco D1
      </div>
    </div>

    {state.loading
      ?<Spinner label="Consultando indicadores da equipe…"/>
      :state.error
        ?<ErrorScreen error={state.error} retry={state.reload}/>
        :d&&<>
          <div className="stats-grid">
            <Stat label="Funcionários ativos" value={d.counts.active_employees} icon={Users} detail="Vínculos ativos na data"/>
            <Stat label="Já registraram entrada" value={d.counts.entered} icon={LogIn} detail="Expediente iniciado" tone="green"/>
            <Stat label="Aguardando entrada" value={d.counts.not_entered} icon={UserRoundX} detail="Com jornada prevista" tone="orange"/>
            <Stat label="Em intervalo" value={d.counts.on_break} icon={Coffee} detail="Pausa em andamento" tone="purple"/>
            <Stat label="Expedientes encerrados" value={d.counts.completed} icon={CheckCircle2} detail="Quatro marcações realizadas" tone="green"/>
            <Stat label="Registros incompletos" value={d.counts.incomplete} icon={AlertTriangle} detail={`${d.counts.late_employees} funcionário(s) com atraso na data`} tone="orange"/>
            <Stat label="Análises pendentes" value={d.counts.pending} icon={MessageSquareText} detail="Justificativas e horas positivas" tone="purple"/>
            <Stat label="Horas realizadas no mês" value={hm(d.counts.worked_minutes)} icon={Clock3} detail="Somente intervalos trabalhados"/>
          </div>

          <div className="dashboard-middle">
            <section className="panel activity-panel">
              <div className="panel-header">
                <div>
                  <h3>Horas realizadas no período</h3>
                  <p>Tempo registrado por dia · {month.split('-').reverse().join('/')}</p>
                </div>
                <span className="chart-legend"><i/> Horas trabalhadas</span>
              </div>

              {d.trend.some((v:any)=>v.worked_minutes>0)
                ?<div className="chart-container">
                  <div className="bar-chart">
                    {d.trend.map((v:any)=>{
                      const max=Math.max(
                        ...d.trend.map((v:any)=>v.worked_minutes),60
                      );

                      return <div
                        className="chart-col"
                        key={v.date}
                        title={`${brDate(v.date)}: ${hm(v.worked_minutes)}`}
                      >
                        <div>
                          <i style={{
                            height:Math.max(
                              v.worked_minutes?3:0,
                              v.worked_minutes/max*100
                            )+'%'
                          }}/>
                        </div>
                        <span>{v.date.slice(8)}</span>
                      </div>;
                    })}
                  </div>
                  <p className="chart-note">
                    Valores obtidos dos registros e ajustes autorizados,
                    sem dados simulados.
                  </p>
                </div>
                :<Empty
                  title="O período ainda não tem horas registradas"
                  text="O gráfico será preenchido automaticamente quando houver marcações de trabalho."
                  icon={Clock3}
                />
              }
            </section>

            <section className="dashboard-tip">
              <div className="tip-icon"><ShieldCheck size={25}/></div>
              <div className="eyebrow">CONFERÊNCIA RESPONSÁVEL</div>
              <h3>O fechamento começa com bons registros.</h3>
              <p>
                Confira marcações incompletas, analise justificativas
                e aprove horas positivas antes de fechar o mês.
              </p>
              <Link to="/admin/relatorios" className="text-link">
                Conferir folhas <ArrowUpRight size={17}/>
              </Link>
            </section>
          </div>

          <section className="panel team-today">
            <div className="panel-header">
              <div>
                <h3>Jornada da equipe</h3>
                <p>
                  {brDate(date)} · {rows.length} funcionário
                  {rows.length!==1?'s':''} na consulta
                </p>
              </div>
              <Link to="/admin/registros" className="text-link">
                Ver registros <ArrowUpRight size={15}/>
              </Link>
            </div>

            <div className="table-toolbar">
              <div className="search-input">
                <Search size={17}/>
                <input
                  aria-label="Buscar na equipe"
                  placeholder="Buscar nome ou matrícula…"
                  value={search}
                  onChange={e=>setSearch(e.target.value)}
                />
              </div>

              <Select
                aria-label="Filtrar situação"
                value={status}
                onChange={e=>setStatus(e.target.value)}
              >
                <option value="all">Todas as situações</option>
                <option value="working">Em expediente</option>
                <option value="on_break">Em intervalo</option>
                <option value="completed">Encerrado</option>
                <option value="not_started">Não iniciado</option>
                <option value="absent">Ausência</option>
                <option value="incomplete">Incompleto</option>
              </Select>
            </div>

            {!rows.length
              ?<Empty
                title={d.rows.length?'Nenhum resultado para este filtro':'Sua equipe começa aqui'}
                text={d.rows.length?'Tente outro nome ou situação.':'Cadastre uma jornada e adicione seu primeiro funcionário.'}
                icon={Users}
                action={!d.rows.length&&
                  <Link className="btn btn-primary" to="/admin/funcionarios">
                    Gerenciar funcionários <ArrowUpRight size={16}/>
                  </Link>
                }
              />
              :<div className="table-scroll">
                <table className="data-table">
                  <thead>
                    <tr>
                      <th>Funcionário</th>
                      <th>Situação</th>
                      <th>Entrada</th>
                      <th>Intervalo</th>
                      <th>Retorno</th>
                      <th>Saída</th>
                      <th>Realizadas</th>
                      <th/>
                    </tr>
                  </thead>
                  <tbody>
                    {rows.map((r:any)=>
                      <tr key={r.employee.id}>
                        <td>
                          <div className="person-cell">
                            <Initials name={r.employee.full_name}/>
                            <div>
                              <strong>{r.employee.full_name}</strong>
                              <small>Matrícula {r.employee.registration}</small>
                            </div>
                          </div>
                        </td>
                        <td><Badge status={r.day.status}/></td>
                        {r.day.marks.map((m:number|null,i:number)=>
                          <td className="number" key={i}>
                            {clock(m,r.day.timezone)}
                          </td>
                        )}
                        <td className="number strong">
                          {hm(r.day.worked_minutes)}
                        </td>
                        <td>
                          <Link
                            to={`/admin/relatorios?funcionario=${r.employee.id}&mes=${month}`}
                            className="icon-btn"
                            aria-label={`Abrir folha de ${r.employee.full_name}`}
                          >
                            <ArrowUpRight size={18}/>
                          </Link>
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            }
          </section>
        </>
    }
  </>;
}

export function ResetLinkModal({
  result,onClose
}:{
  result:any;
  onClose:()=>void;
}){
  const toast=useToast();
  const url=window.location.origin+result.reset_path;

  return <Modal
    title="Link de recuperação emitido"
    description="Este link é exibido somente agora. Entregue-o apenas após verificar a identidade."
    onClose={onClose}
  >
    <Notice type="warning">
      Uso único · expira em {new Date(result.expires_at).toLocaleTimeString(
        'pt-BR',{hour:'2-digit',minute:'2-digit'}
      )}. Não envie por canais públicos.
    </Notice>

    <Field label="Link de redefinição">
      <textarea
        readOnly
        value={url}
        rows={4}
        onFocus={e=>e.target.select()}
      />
    </Field>

    <div className="modal-actions">
      <Button variant="secondary" onClick={onClose}>
        Fechar
      </Button>
      <Button
        icon={Copy}
        onClick={async()=>{
          try{
            await navigator.clipboard.writeText(url);
            toast('Link copiado. Compartilhe por um canal seguro.');
          }catch{
            toast('Selecione o link e copie manualmente.','info');
          }
        }}
      >
        Copiar link
      </Button>
    </div>
  </Modal>;
}

export function EmployeesPage(){
  const {config}=useSession();
  const state=useData('/admin/employees');
  const plans=useData('/admin/schedules');
  const toast=useToast();
  const {reauth}=useSecurity();

  const [search,setSearch]=useState('');
  const [status,setStatus]=useState('all');
  const [edit,setEdit]=useState<any|false>(false);
  const [profileId,setProfileId]=useState<string|null>(null);
  const [reset,setReset]=useState<any>(null);
  const [actionBusy,setActionBusy]=useState('');

  // Exclusao logica: preserva todos os registros de ponto e historico.
  const [deleteTarget,setDeleteTarget]=useState<any|null>(null);
  const [deleteConfirm,setDeleteConfirm]=useState('');
  const [deleteBusy,setDeleteBusy]=useState(false);
  const [deleteError,setDeleteError]=useState<unknown>(null);

  const profile=useData(
    profileId?`/admin/employees/${profileId}`:null
  );

  const [newSchedule,setNewSchedule]=useState('');
  const [effective,setEffective]=useState(()=>{
    const d=new Date(config.server_now);
    d.setUTCDate(d.getUTCDate()+1);
    return localInput(d.getTime(),config.timezone).slice(0,10);
  });

  const rows=state.data?.filter((e:any)=>
    (
      e.full_name.toLowerCase().includes(search.toLowerCase())||
      e.registration.toLowerCase().includes(search.toLowerCase())||
      e.login.toLowerCase().includes(search.toLowerCase())
    )&&
    (status==='all'||e.status===status)
  )||[];

  const issueReset=async(userId:string)=>{
    setActionBusy(userId);
    try{
      await reauth();
      setReset(
        await api(`/admin/users/${userId}/reset`,'POST',{})
      );
    }catch(e){
      if(errorMessage(e)!=='Operação cancelada.'){
        toast(errorMessage(e),'error');
      }
    }finally{
      setActionBusy('');
    }
  };

  const closeDelete=()=>{
    if(deleteBusy)return;
    setDeleteTarget(null);
    setDeleteConfirm('');
    setDeleteError(null);
  };

  const removeEmployee=async()=>{
    if(!deleteTarget||deleteConfirm!=='EXCLUIR'||deleteBusy)return;

    setDeleteBusy(true);
    setDeleteError(null);

    try{
      await reauth();
      const result=await api(
        `/admin/employees/${deleteTarget.id}`,
        'DELETE',
        {confirmation:'EXCLUIR'}
      );
      setDeleteTarget(null);
      setDeleteConfirm('');
      setProfileId(null);
      toast(result.message);
      state.reload();
    }catch(err){
      if(errorMessage(err)!=='Operação cancelada.'){
        setDeleteError(err);
      }
    }finally{
      setDeleteBusy(false);
    }
  };

  const cancelFutureAssignment=async(a:any)=>{
    if(!profileId||actionBusy)return;

    const confirmed=window.confirm(
      `Cancelar a atribuição da jornada "${a.name}" prevista para ${brDate(a.effective_from)}?\n\nO registro original será preservado na auditoria. Esta ação não pode ser desfeita.`
    );

    if(!confirmed)return;

    setActionBusy(`cancel-${a.id}`);

    try{
      await reauth();

      const r=await api(
        `/admin/employees/${profileId}/schedule/${a.id}/cancel`,
        'POST',
        {}
      );

      toast(r.message);
      profile.reload();
      state.reload();
      plans.reload();
    }catch(e){
      if(errorMessage(e)!=='Operação cancelada.'){
        toast(errorMessage(e),'error');
      }
    }finally{
      setActionBusy('');
    }
  };

  return <>
    <PageHeader
      eyebrow="PESSOAS E ACESSOS"
      title="Funcionários"
      description="Organize sua equipe, jornadas e permissões de acesso."
      actions={
        <Button icon={Plus} onClick={()=>setEdit({})}>
          Novo funcionário
        </Button>
      }
    />

    <div className="team-summary-pills">
      <span>
        <Users size={16}/> {state.data?.length||0} cadastrados
      </span>
      <span>
        <i className="dot-green"/>
        {state.data?.filter((e:any)=>e.status==='active').length||0} ativos
      </span>
      <span>
        <i className="dot-gray"/>
        {state.data?.filter((e:any)=>e.status!=='active').length||0} bloqueados / desligados
      </span>
    </div>

    <section className="panel">
      <div className="table-toolbar">
        <div className="search-input">
          <Search size={18}/>
          <input
            placeholder="Buscar nome, matrícula ou usuário…"
            aria-label="Buscar funcionários"
            value={search}
            onChange={e=>setSearch(e.target.value)}
          />
        </div>

        <Select
          aria-label="Situação do funcionário"
          value={status}
          onChange={e=>setStatus(e.target.value)}
        >
          <option value="all">Todas as situações</option>
          <option value="active">Ativos</option>
          <option value="blocked">Bloqueados</option>
          <option value="terminated">Desligados</option>
        </Select>
      </div>

      {state.loading
        ?<Spinner/>
        :state.error
          ?<ErrorScreen error={state.error} retry={state.reload}/>
          :!rows.length
            ?<Empty
              title={state.data?.length?'Nenhum funcionário encontrado':'Pessoas são o começo de tudo'}
              text={state.data?.length?'Revise a busca ou os filtros.':'Cadastre uma jornada e crie os acessos individuais da sua equipe.'}
              icon={Users}
              action={
                <Button icon={Plus} onClick={()=>setEdit({})}>
                  Cadastrar funcionário
                </Button>
              }
            />
            :<div className="table-scroll">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Funcionário / matrícula</th>
                    <th>Cargo</th>
                    <th>Jornada atual</th>
                    <th>Admissão</th>
                    <th>Situação</th>
                    <th className="align-right">Ações</th>
                  </tr>
                </thead>
                <tbody>
                  {rows.map((e:any)=>
                    <tr key={e.id}>
                      <td>
                        <div className="person-cell">
                          <Initials name={e.full_name}/>
                          <div>
                            <strong>{e.full_name}</strong>
                            <small>{e.registration} · @{e.login}</small>
                          </div>
                        </div>
                      </td>
                      <td>{e.job_title||'—'}</td>
                      <td>{e.schedule_name||'Sem jornada vigente'}</td>
                      <td>{brDate(e.admission_date)}</td>
                      <td><Badge status={e.status}/></td>
                      <td>
                        <div className="table-actions">
                          <button
                            className="icon-btn"
                            title="Ver perfil e histórico"
                            aria-label={`Ver perfil de ${e.full_name}`}
                            onClick={()=>{
                              setProfileId(e.id);
                              setNewSchedule('');
                            }}
                          >
                            <Eye size={17}/>
                          </button>
                          <button
                            className="icon-btn"
                            title="Editar funcionário"
                            aria-label={`Editar ${e.full_name}`}
                            onClick={()=>setEdit(e)}
                          >
                            <Pencil size={16}/>
                          </button>
                          <button
                            className="icon-btn"
                            title="Emitir link de recuperação"
                            aria-label={`Redefinir senha de ${e.full_name}`}
                            disabled={actionBusy===e.user_id||e.status!=='active'}
                            onClick={()=>issueReset(e.user_id)}
                          >
                            <KeyRound size={17}/>
                          </button>
                          <button
                            className="icon-btn"
                            type="button"
                            title="Excluir funcionário"
                            aria-label={`Excluir ${e.full_name}`}
                            style={{color:'#1f2937'}}
                            disabled={deleteBusy}
                            onClick={()=>{
                              setDeleteTarget(e);
                              setDeleteConfirm('');
                              setDeleteError(null);
                            }}
                          >
                            <Trash2 size={17}/>
                          </button>
                        </div>
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
      }
    </section>

    {deleteTarget&&
      <Modal
        title="Excluir funcionário?"
        description="Confirme a remoção do cadastro da lista de funcionários."
        onClose={closeDelete}
      >
        <Notice type="warning">
          <strong>{deleteTarget.full_name}</strong>
          <p>Matrícula: {deleteTarget.registration}</p>
          <p>
            Esta ação vai retirar o funcionário da lista principal e
            bloquear seu acesso ao sistema. As marcações de ponto,
            os relatórios e o histórico administrativo serão preservados.
          </p>
        </Notice>

        <Field
          label="Digite EXCLUIR para confirmar"
          hint="Esta confirmação evita exclusões acidentais."
        >
          <input
            type="text"
            value={deleteConfirm}
            onChange={e=>setDeleteConfirm(e.target.value)}
            placeholder="EXCLUIR"
            autoComplete="off"
            disabled={deleteBusy}
          />
        </Field>

        <InlineError error={deleteError}/>

        <div className="modal-actions">
          <Button
            type="button"
            variant="secondary"
            disabled={deleteBusy}
            onClick={closeDelete}
          >
            Cancelar
          </Button>
          <Button
            type="button"
            variant="danger"
            icon={Trash2}
            disabled={deleteConfirm!=='EXCLUIR'||deleteBusy}
            busy={deleteBusy}
            onClick={removeEmployee}
          >
            Excluir funcionário
          </Button>
        </div>
      </Modal>
    }

    {edit!==false&&
      <EmployeeForm
        existing={edit}
        schedules={(plans.data||[]).filter((s:any)=>!s.archived)}
        schedulesLoading={plans.loading}
        onClose={()=>setEdit(false)}
        onSaved={()=>{
          setEdit(false);
          state.reload();
          profile.reload();
        }}
      />
    }

    {profileId&&
      <Modal
        wide
        title="Perfil do funcionário"
        description="Dados do vínculo, versões da jornada e histórico administrativo."
        onClose={()=>setProfileId(null)}
      >
        {profile.loading
          ?<Spinner/>
          :profile.error
            ?<InlineError error={profile.error}/>
            :profile.data&&<>
              <div className="profile-hero">
                <Initials name={profile.data.employee.full_name}/>
                <div>
                  <h2>{profile.data.employee.full_name}</h2>
                  <p>
                    {profile.data.employee.registration} · {profile.data.employee.job_title||'Cargo não informado'}
                  </p>
                </div>
                <Badge status={profile.data.employee.status}/>
              </div>

              <div className="profile-details">
                <span>
                  Usuário <strong>{profile.data.employee.login}</strong>
                </span>
                <span>
                  E-mail <strong>{profile.data.employee.email||'Não informado'}</strong>
                </span>
                <span>
                  Admissão <strong>{brDate(profile.data.employee.admission_date)}</strong>
                </span>
                <span>
                  CPF <strong>
                    {profile.data.employee.cpf_last4
                      ?`•••.•••.•${profile.data.employee.cpf_last4.slice(0,2)}-${profile.data.employee.cpf_last4.slice(2)}`
                      :'Não coletado'
                    }
                  </strong>
                </span>
              </div>

              {profile.data.employee.notes&&
                <div className="admin-notes">
                  <strong>Observações administrativas</strong>
                  <p>{profile.data.employee.notes}</p>
                </div>
              }

              <div className="action-row">
                <Link
                  className="btn btn-primary"
                  to={`/admin/relatorios?funcionario=${profileId}`}
                >
                  Abrir folha de ponto <ArrowUpRight size={16}/>
                </Link>

                <Button
                  variant="secondary"
                  icon={KeyRound}
                  busy={actionBusy===profile.data.employee.user_id}
                  disabled={profile.data.employee.status!=='active'}
                  onClick={()=>issueReset(profile.data.employee.user_id)}
                >
                  Redefinir senha
                </Button>
              </div>

              <hr/>

              <h3 className="section-title">Atribuir nova jornada</h3>
              <p className="muted small">
                Cria uma nova vigência sem alterar dias já iniciados
                ou períodos fechados.
              </p>

              <form onSubmit={async e=>{
                e.preventDefault();
                setActionBusy('schedule');

                try{
                  await reauth();

                  const r=await api(
                    `/admin/employees/${profileId}/schedule`,
                    'POST',
                    {
                      schedule_id:newSchedule,
                      effective_from:effective
                    }
                  );

                  toast(r.message);
                  profile.reload();
                  state.reload();
                }catch(e){
                  if(errorMessage(e)!=='Operação cancelada.'){
                    toast(errorMessage(e),'error');
                  }
                }finally{
                  setActionBusy('');
                }
              }}>
                <div className="form-grid">
                  <Field label="Jornada">
                    <Select
                      value={newSchedule}
                      onChange={e=>setNewSchedule(e.target.value)}
                      required
                    >
                      <option value="">Selecione uma jornada</option>
                      {plans.data
                        ?.filter((s:any)=>!s.archived)
                        .map((s:any)=>
                          <option key={s.id} value={s.id}>
                            {s.name}
                          </option>
                        )
                      }
                    </Select>
                  </Field>

                  <Field label="Válida a partir de">
                    <input
                      type="date"
                      min={localInput(Date.now(),config.timezone).slice(0,10)}
                      value={effective}
                      onChange={e=>setEffective(e.target.value)}
                      required
                    />
                  </Field>
                </div>

                <Button
                  busy={actionBusy==='schedule'}
                  icon={CalendarClock}
                >
                  Atribuir jornada
                </Button>
              </form>

              <h3 className="section-title spaced">
                Histórico de jornadas
              </h3>

              <div className="compact-list">
                {profile.data.assignments.length
                  ?profile.data.assignments.map((a:any)=>{
                    const isFuture=
                      a.effective_from>
                      localInput(Date.now(),config.timezone).slice(0,10);

                    return <div key={a.id}>
                      <span>
                        {a.name}
                        <small>
                          {a.config.start} — {a.config.end} · intervalo{' '}
                          {a.config.break_start}–{a.config.break_end}
                        </small>
                      </span>

                      <span style={{
                        display:'flex',
                        alignItems:'center',
                        gap:10,
                        flexWrap:'wrap',
                        justifyContent:'flex-end'
                      }}>
                        <strong>
                          {isFuture?'Prevista para':'Desde'}{' '}
                          {brDate(a.effective_from)}
                        </strong>

                        {isFuture&&
                          <Button
                            type="button"
                            variant="secondary"
                            icon={XCircle}
                            busy={actionBusy===`cancel-${a.id}`}
                            disabled={!!actionBusy}
                            onClick={()=>cancelFutureAssignment(a)}
                          >
                            Cancelar atribuição
                          </Button>
                        }
                      </span>
                    </div>;
                  })
                  :<p className="muted">
                    Nenhuma jornada ativa encontrada.
                  </p>
                }
              </div>

              <h3 className="section-title spaced">
                Histórico administrativo
              </h3>

              <div className="compact-list history-list">
                {profile.data.history.length
                  ?profile.data.history.map((a:any)=>
                    <div key={a.id}>
                      <span>
                        {a.action}
                        <small>{a.actor_name||'Sistema'}</small>
                      </span>
                      <time>
                        {new Date(a.created_at).toLocaleString(
                          'pt-BR',{timeZone:config.timezone}
                        )}
                      </time>
                    </div>
                  )
                  :<p className="muted">
                    Nenhuma ação registrada.
                  </p>
                }
              </div>
            </>
        }
      </Modal>
    }

    {reset&&
      <ResetLinkModal
        result={reset}
        onClose={()=>setReset(null)}
      />
    }
  </>;
}

function EmployeeForm({
  existing,schedules,schedulesLoading,onClose,onSaved
}:{
  existing:any;
  schedules:any[];
  schedulesLoading:boolean;
  onClose:()=>void;
  onSaved:()=>void;
}){
  const editing=!!existing.id;
  const {config}=useSession();
  const toast=useToast();
  const {reauth}=useSecurity();

  const [busy,setBusy]=useState(false);
  const [error,setError]=useState<unknown>(null);
  const [changeCpf,setChangeCpf]=useState(!editing);

  const [form,setForm]=useState({
    full_name:existing.full_name||'',
    registration:existing.registration||'',
    cpf:'',
    job_title:existing.job_title||'',
    admission_date:existing.admission_date||
      localInput(config.server_now,config.timezone).slice(0,10),
    employment_end:existing.employment_end||'',
    status:existing.status||'active',
    notes:existing.notes||'',
    login:existing.login||'',
    email:existing.email||'',
    initial_password:'',
    schedule_id:schedules[0]?.id||''
  });

  useEffect(()=>{
    if(!editing&&!form.schedule_id&&schedules[0]){
      setForm(v=>({...v,schedule_id:schedules[0].id}));
    }
  },[editing,schedules,form.schedule_id]);

  const set=(key:string,value:string)=>
    setForm(v=>({...v,[key]:value}));

  const plan=schedules.find(p=>p.id===form.schedule_id);

  return <Modal
    wide
    title={editing?'Editar funcionário':'Novo funcionário'}
    description={editing
      ?'Atualize os dados do vínculo. Todas as alterações ficam na auditoria.'
      :'Crie um vínculo e um acesso individual. A senha inicial deve ser trocada no primeiro login.'
    }
    onClose={onClose}
  >
    {!editing&&schedulesLoading
      ?<Spinner label="Carregando jornadas…"/>
      :!editing&&!schedules.length
        ?<>
          <Notice type="warning">
            Crie uma jornada antes de cadastrar o primeiro funcionário.
          </Notice>
          <Link className="btn btn-primary" to="/admin/jornadas">
            Criar jornada <ArrowUpRight size={17}/>
          </Link>
        </>
        :<form onSubmit={async e=>{
          e.preventDefault();
          setError(null);
          setBusy(true);

          try{
            if(editing)await reauth();

            const {initial_password,schedule_id,...rest}=form;

            const payload={
              ...rest,
              cpf:changeCpf?form.cpf:undefined,
              employment_end:form.employment_end||null,
              ...(!editing?{initial_password,schedule_id}:{})
            };

            const r=await api(
              editing
                ?`/admin/employees/${existing.id}`
                :'/admin/employees',
              editing?'PUT':'POST',
              payload
            );

            toast(r.message);
            onSaved();
          }catch(e){
            if(errorMessage(e)!=='Operação cancelada.'){
              setError(e);
            }
          }finally{
            setBusy(false);
          }
        }}>
          <div className="form-section-label">
            <UserRound size={16}/> DADOS DO FUNCIONÁRIO
          </div>

          <div className="form-grid">
            <Field label="Nome completo">
              <input
                value={form.full_name}
                onChange={e=>set('full_name',e.target.value)}
                minLength={3}
                maxLength={140}
                required
                autoComplete="off"
              />
            </Field>

            <Field label="Matrícula / código interno">
              <input
                value={form.registration}
                onChange={e=>set('registration',e.target.value)}
                maxLength={40}
                required
              />
            </Field>

            <Field label="Cargo / função">
              <input
                value={form.job_title}
                onChange={e=>set('job_title',e.target.value)}
                maxLength={100}
              />
            </Field>

            <Field label="Data de admissão">
              <input
                type="date"
                value={form.admission_date}
                onChange={e=>set('admission_date',e.target.value)}
                min="1900-01-01"
                max="2100-12-31"
                required
              />
            </Field>

            <Field label="Situação">
              <Select
                value={form.status}
                onChange={e=>{
                  set('status',e.target.value);
                  if(e.target.value!=='terminated'){
                    set('employment_end','');
                  }
                }}
              >
                <option value="active">Ativo</option>
                <option value="blocked">Bloqueado</option>
                <option value="terminated">Desligado</option>
              </Select>
            </Field>

            {form.status==='terminated'&&
              <Field label="Data do desligamento">
                <input
                  type="date"
                  min={form.admission_date}
                  value={form.employment_end}
                  onChange={e=>set('employment_end',e.target.value)}
                  required
                />
              </Field>
            }
          </div>

          {editing&&
            <label className="checkbox-field">
              <input
                type="checkbox"
                checked={changeCpf}
                onChange={e=>setChangeCpf(e.target.checked)}
              />
              Alterar ou remover CPF armazenado
            </label>
          }

          {changeCpf&&
            <Field
              label="CPF (opcional)"
              hint={editing
                ?'Campo vazio remove o CPF. O número é cifrado no servidor e não é devolvido por inteiro.'
                :'Colete somente se houver finalidade administrativa. O número será cifrado no banco.'
              }
            >
              <input
                value={form.cpf}
                onChange={e=>set('cpf',e.target.value)}
                inputMode="numeric"
                maxLength={14}
                autoComplete="off"
                placeholder="000.000.000-00"
              />
            </Field>
          }

          <div className="form-section-label">
            <ShieldCheck size={16}/> ACESSO INDIVIDUAL
          </div>

          <div className="form-grid">
            <Field label="Usuário de acesso">
              <input
                value={form.login}
                onChange={e=>set('login',e.target.value)}
                minLength={3}
                maxLength={120}
                required
                autoComplete="off"
              />
            </Field>

            <Field label="E-mail (opcional)">
              <input
                type="email"
                value={form.email}
                onChange={e=>set('email',e.target.value)}
                maxLength={200}
                autoComplete="off"
              />
            </Field>

            {!editing&&
              <Field
                label="Senha inicial"
                hint="No mínimo 12 caracteres. Entregue por um canal seguro."
              >
                <input
                  type="password"
                  value={form.initial_password}
                  onChange={e=>set('initial_password',e.target.value)}
                  minLength={12}
                  maxLength={128}
                  autoComplete="new-password"
                  required
                />
              </Field>
            }
          </div>

          {!editing&&<>
            <div className="form-section-label">
              <CalendarClock size={16}/> JORNADA CONTRATUAL
            </div>

            <Field label="Jornada / escala">
              <Select
                value={form.schedule_id}
                onChange={e=>set('schedule_id',e.target.value)}
                required
              >
                {schedules.map(s=>
                  <option value={s.id} key={s.id}>
                    {s.name}
                  </option>
                )}
              </Select>
            </Field>

            {plan&&
              <div className="schedule-preview">
                <strong>
                  {plan.config.start} — {plan.config.end}
                </strong>
                <span>
                  Intervalo {plan.config.break_start} —{' '}
                  {plan.config.break_end}{' '}
                  {plan.config.paid_break
                    ?'(remunerado)'
                    :'(não remunerado)'
                  }
                </span>
                <span>
                  {plan.config.weekdays.map(
                    (v:number)=>weekdayNames[v]
                  ).join(' · ')}
                </span>
                <span>
                  {hm(plan.daily)} h/dia · {hm(plan.weekly)} h/semana
                </span>
              </div>
            }
          </>}

          <Field
            label="Observações administrativas"
            hint="Visíveis somente aos administradores."
          >
            <textarea
              value={form.notes}
              onChange={e=>set('notes',e.target.value)}
              maxLength={2000}
              rows={3}
            />
          </Field>

          <InlineError error={error}/>

          <div className="modal-actions">
            <Button
              type="button"
              variant="secondary"
              onClick={onClose}
            >
              Cancelar
            </Button>
            <Button busy={busy}>
              {editing?'Salvar alterações':'Cadastrar funcionário'}
            </Button>
          </div>
        </form>
    }
  </Modal>;
}
